from .algorithm import rho_term_predict
